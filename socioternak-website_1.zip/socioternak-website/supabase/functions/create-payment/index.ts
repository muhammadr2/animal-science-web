// supabase/functions/create-payment/index.ts
// Membuat transaksi Midtrans Snap untuk sebuah order. Berjalan di server Supabase;
// SERVER KEY tidak pernah sampai ke browser.
//
// ⚠️ Saya tidak bisa mengetesnya terhadap Midtrans dari sini. Uji di SANDBOX Midtrans
//    dan verifikasi endpoint/format terbaru di dokumentasi Midtrans sebelum produksi.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { order_id } = await req.json();
    const authHeader = req.headers.get("Authorization") ?? "";

    // Client "atas nama user" → RLS memastikan order memang milik pemanggil.
    const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: order, error } = await sb.from("orders").select("id,subtotal,buyer_id").eq("id", order_id).single();
    if (error || !order) return json({ error: "order tidak ditemukan / bukan milik Anda" }, 404);

    const serverKey = Deno.env.get("MIDTRANS_SERVER_KEY")!;
    const isProd = Deno.env.get("MIDTRANS_IS_PRODUCTION") === "true";
    const base = isProd ? "https://app.midtrans.com" : "https://app.sandbox.midtrans.com";
    const midOrderId = `SOCIO-${order.id}-${Date.now()}`;

    const res = await fetch(`${base}/snap/v1/transactions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": "Basic " + btoa(serverKey + ":"),
      },
      body: JSON.stringify({
        transaction_details: { order_id: midOrderId, gross_amount: Math.round(Number(order.subtotal)) },
      }),
    });
    const data = await res.json();
    if (!res.ok) return json({ error: data }, 400);

    // Simpan referensi (service role → boleh update tanpa terhalang RLS).
    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    await admin.from("orders").update({ midtrans_order_id: midOrderId, payment_status: "PENDING" }).eq("id", order.id);

    return json({ token: data.token, redirect_url: data.redirect_url });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});
