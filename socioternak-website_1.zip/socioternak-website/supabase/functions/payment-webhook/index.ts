// supabase/functions/payment-webhook/index.ts
// Menerima notifikasi Midtrans, MEMVERIFIKASI TANDA TANGAN, lalu memperbarui status order.
// Daftarkan URL fungsi ini di Midtrans Dashboard → Settings → Payment Notification URL.
//
// ⚠️ Tidak teruji terhadap Midtrans dari sini. Uji di sandbox; verifikasi field notifikasi
//    terbaru di dokumentasi Midtrans.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  try {
    const body = await req.json();
    const { order_id, status_code, gross_amount, signature_key, transaction_status, fraud_status } = body;
    const serverKey = Deno.env.get("MIDTRANS_SERVER_KEY")!;

    // Verifikasi: sha512(order_id + status_code + gross_amount + serverKey)
    const enc = new TextEncoder().encode(`${order_id}${status_code}${gross_amount}${serverKey}`);
    const digest = await crypto.subtle.digest("SHA-512", enc);
    const hash = [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
    if (hash !== signature_key) return new Response("invalid signature", { status: 403 });

    // Petakan status Midtrans → status pembayaran & order kita.
    let pay = "PENDING";
    if (transaction_status === "capture") pay = fraud_status === "accept" ? "PAID" : "REVIEW";
    else if (transaction_status === "settlement") pay = "PAID";
    else if (["cancel", "deny", "expire"].includes(transaction_status)) pay = "FAILED";
    else if (transaction_status === "pending") pay = "PENDING";

    const orderStatus = pay === "PAID" ? "CONFIRMED" : pay === "FAILED" ? "CANCELLED" : "PENDING";

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    await admin.from("orders").update({ payment_status: pay, status: orderStatus }).eq("midtrans_order_id", order_id);

    return new Response("ok");
  } catch (e) {
    return new Response(String(e), { status: 500 });
  }
});
