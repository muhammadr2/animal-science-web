// ============================================================================
// SocioTernak IoT bridge — MQTT broker  ->  Supabase (tabel sensor_logs)
// Jalankan di server yang selalu hidup (Railway / Fly.io / VPS). BUKAN di Vercel
// (serverless tidak bisa menjaga koneksi MQTT) dan BUKAN di browser.
//
// Perangkat mem-publish ke topik:  socioternak/<coop_id>/<sensor_code>
// dengan payload JSON:             {"value": 31.4}
//
// Menulis pakai SERVICE ROLE key => menembus RLS (itu memang perannya di server).
// Jalankan:  npm install && npm start
// ============================================================================
require("dotenv").config();
const mqtt = require("mqtt");
const { createClient } = require("@supabase/supabase-js");

const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, MQTT_BROKER_URL, MQTT_USERNAME, MQTT_PASSWORD } = process.env;
if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY || !MQTT_BROKER_URL) {
  console.error("Lengkapi .env (SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, MQTT_BROKER_URL).");
  process.exit(1);
}

const sb = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });

// cache code -> sensor_id supaya tidak query berulang
const sensorCache = new Map();
async function resolveSensorId(code) {
  if (sensorCache.has(code)) return sensorCache.get(code);
  const { data, error } = await sb.from("sensors").select("id").eq("code", code).single();
  if (error || !data) return null;
  sensorCache.set(code, data.id);
  return data.id;
}

const client = mqtt.connect(MQTT_BROKER_URL, {
  username: MQTT_USERNAME || undefined,
  password: MQTT_PASSWORD || undefined,
  reconnectPeriod: 3000, // auto-reconnect saat putus
});

client.on("connect", () => {
  console.log("[bridge] tersambung ke broker");
  client.subscribe("socioternak/+/+", (err) => {
    if (err) console.error("[bridge] gagal subscribe:", err.message);
    else console.log("[bridge] subscribe: socioternak/+/+");
  });
});

client.on("message", async (topic, buf) => {
  try {
    const parts = topic.split("/"); // ["socioternak","<coop>","<code>"]
    const code = parts[2];
    if (!code) return;
    const { value } = JSON.parse(buf.toString());
    if (typeof value !== "number" || Number.isNaN(value)) return;

    const sensorId = await resolveSensorId(code);
    if (!sensorId) { console.warn("[bridge] sensor tak dikenal:", code); return; }

    const { error } = await sb.from("sensor_logs").insert({ sensor_id: sensorId, value });
    if (error) console.error("[bridge] insert gagal:", error.message);
    // INSERT ini yang disiarkan Supabase Realtime ke dashboard peternak.
  } catch (e) {
    console.error("[bridge] error pesan:", e.message);
  }
});

client.on("error", (e) => console.error("[bridge] mqtt error:", e.message));
process.on("SIGTERM", () => { client.end(); process.exit(0); });
process.on("SIGINT", () => { client.end(); process.exit(0); });
