// ============================================================================
// Simulator perangkat — mem-publish data sensor palsu ke broker MQTT supaya
// seluruh alur (device -> broker -> bridge -> Supabase -> dashboard) bisa
// diuji tanpa hardware. Jalankan di terminal terpisah:  npm run simulate
// ============================================================================
require("dotenv").config();
const mqtt = require("mqtt");
const { createClient } = require("@supabase/supabase-js");

const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, MQTT_BROKER_URL, MQTT_USERNAME, MQTT_PASSWORD } = process.env;
const sb = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });

// nilai realistis per tipe sensor
function fakeValue(type) {
  switch (type) {
    case "TEMPERATURE": return 27 + Math.random() * 6;
    case "HUMIDITY":    return 55 + Math.random() * 20;
    case "AMMONIA":     return 8 + Math.random() * 18;
    case "WATER_FLOW":  return 3 + Math.random() * 5;
    case "FEED_LEVEL":  return 25 + Math.random() * 50;
    default:            return Math.random() * 100;
  }
}

(async () => {
  const { data: sensors, error } = await sb.from("sensors").select("id,code,type,coop_id");
  if (error || !sensors || !sensors.length) {
    console.error("Tidak ada sensor. Jalankan supabase-schema-secure.sql & daftar minimal 1 akun dulu.");
    process.exit(1);
  }
  const client = mqtt.connect(MQTT_BROKER_URL, { username: MQTT_USERNAME || undefined, password: MQTT_PASSWORD || undefined });
  client.on("connect", () => {
    console.log(`[sim] tersambung. Mem-publish ${sensors.length} sensor tiap 5 dtk. Ctrl+C untuk berhenti.`);
    setInterval(() => {
      sensors.forEach((s) => {
        const topic = `socioternak/${s.coop_id}/${s.code}`;
        const payload = JSON.stringify({ value: +fakeValue(s.type).toFixed(1) });
        client.publish(topic, payload);
      });
      process.stdout.write(".");
    }, 5000);
  });
  client.on("error", (e) => console.error("[sim] error:", e.message));
})();
