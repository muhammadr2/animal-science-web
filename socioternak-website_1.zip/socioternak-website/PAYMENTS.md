# Pembayaran (Midtrans) — panduan pasang

**Jujur di depan:** kode ini benar menurut pola API Midtrans yang saya ketahui, tetapi
**belum saya uji terhadap Midtrans** (tidak ada kredensial/akses dari sisi saya) dan API
pihak ketiga bisa berubah. **Wajib diuji di SANDBOX Midtrans** dan cek dokumentasi
terbaru sebelum menerima uang sungguhan.

## Prasyarat
- Akun Midtrans (mulai dari **Sandbox**). Ambil **Server Key** & **Client Key**.
- Supabase CLI terpasang (`npm i -g supabase`), login, dan `supabase link` ke project.

## Langkah
1. Jalankan `supabase-payments.sql` (tambah kolom pembayaran ke `orders`).
2. Set secret Edge Functions (JANGAN taruh server key di browser):
   ```bash
   supabase secrets set MIDTRANS_SERVER_KEY=SB-Mid-server-xxxx
   supabase secrets set MIDTRANS_IS_PRODUCTION=false
   # SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY biasanya sudah tersedia
   # otomatis untuk Edge Functions; set manual bila perlu.
   ```
3. Deploy kedua fungsi:
   ```bash
   supabase functions deploy create-payment
   supabase functions deploy payment-webhook --no-verify-jwt
   ```
   (`payment-webhook` pakai `--no-verify-jwt` karena dipanggil server Midtrans, bukan user;
   keamanannya dari verifikasi tanda tangan SHA-512, bukan JWT.)
4. Di Midtrans Dashboard → Settings → **Payment Notification URL**, isi:
   `https://<project-ref>.functions.supabase.co/payment-webhook`
5. Di `index.html`, isi **Client Key** pada bagian KONFIGURASI:
   ```js
   const MIDTRANS_CLIENT_KEY = "SB-Mid-client-xxxx";
   ```
   Bila diisi, situs memuat Snap dan alur "Buat Pesanan" langsung membuka pembayaran.
   Bila kosong, pesanan tetap tersimpan tanpa pembayaran (perilaku sebelumnya).

## Alur
`Buat Pesanan` → RPC `create_order` (harga dihitung server) → fungsi `create-payment`
(buat transaksi Snap) → popup Snap → user bayar → Midtrans panggil `payment-webhook` →
status order jadi `CONFIRMED`/`payment_status=PAID`.

## Sebelum ke PRODUKSI
- Ganti `MIDTRANS_IS_PRODUCTION=true` dan pakai Client Key produksi + URL Snap produksi
  (`https://app.midtrans.com/snap/snap.js`).
- Uji semua skenario di sandbox: sukses, pending, gagal, expired.
- Pastikan `create_order` (hardening) aktif agar harga tak bisa dimanipulasi klien.
- Tinjau ulang oleh orang yang paham keamanan pembayaran.
