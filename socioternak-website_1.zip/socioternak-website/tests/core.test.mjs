// tests/core.test.mjs — jalankan: node --test
import test from "node:test";
import assert from "node:assert/strict";
import {
  evaluateSensor, optimizeFeed, buildPedigree, projectedOffspringF,
  inbreedingCoefficient, classifyInbreeding, validateCart, orderSubtotal, splitBySupplier,
} from "../lib/agtech-core.mjs";

const MIN = 60_000;

// ---------------- IoT alert engine ----------------
test("sensor: nilai dalam band = OPTIMAL", () => {
  const rule = { type: "TEMPERATURE", optimalMin: 26, optimalMax: 30, criticalMax: 34, sustainedMs: 10 * MIN };
  const r = evaluateSensor([{ value: 28, recordedAt: new Date() }], rule);
  assert.equal(r.level, "OPTIMAL");
});
test("sensor: breach singkat (< sustained) = WARNING", () => {
  const rule = { type: "TEMPERATURE", optimalMin: 26, optimalMax: 30, criticalMax: 34, sustainedMs: 10 * MIN };
  const t0 = Date.now();
  const readings = [
    { value: 28, recordedAt: new Date(t0 - 3 * MIN) },
    { value: 32, recordedAt: new Date(t0) }, // baru 0 menit breach
  ];
  assert.equal(evaluateSensor(readings, rule).level, "WARNING");
});
test("sensor: breach berkepanjangan (>= sustained) = CRITICAL", () => {
  const rule = { type: "TEMPERATURE", optimalMin: 26, optimalMax: 30, criticalMax: 40, sustainedMs: 10 * MIN };
  const t0 = Date.now();
  const readings = [
    { value: 32, recordedAt: new Date(t0 - 12 * MIN) },
    { value: 33, recordedAt: new Date(t0) },
  ];
  assert.equal(evaluateSensor(readings, rule).level, "CRITICAL");
});
test("sensor: melewati batas kritis keras = CRITICAL langsung", () => {
  const rule = { type: "TEMPERATURE", optimalMin: 26, optimalMax: 30, criticalMax: 34, sustainedMs: 10 * MIN };
  assert.equal(evaluateSensor([{ value: 36, recordedAt: new Date() }], rule).level, "CRITICAL");
});

// ---------------- feed optimizer ----------------
const ing = [
  { name: "Jagung", cpPercent: 8.5, pricePerKg: 6000 },
  { name: "Dedak", cpPercent: 12, pricePerKg: 3500 },
  { name: "Bungkil", cpPercent: 44, pricePerKg: 11000 },
];
test("pakan: target tercapai & biaya positif", () => {
  const r = optimizeFeed(ing, 19);
  assert.equal(r.feasible, true);
  assert.ok(Math.abs(r.achievedCP - 19) <= 0.25);
  assert.ok(r.costPerKg > 0);
  const sum = r.proportions.reduce((s, p) => s + p.percent, 0);
  assert.ok(Math.abs(sum - 100) < 0.01, "proporsi harus jumlah 100%");
});
test("pakan: target mustahil (> CP tertinggi) = tidak feasible", () => {
  assert.equal(optimizeFeed(ing, 50).feasible, false);
});

// ---------------- inbreeding ----------------
function ped(extra = []) {
  return buildPedigree([
    { id: "s", sireId: null, damId: null, generation: 0 },
    { id: "d", sireId: null, damId: null, generation: 0 },
    ...extra,
  ]);
}
test("F: kawin sekandang penuh (full-sib) = 0.25", () => {
  const p = buildPedigree([
    { id: "s", sireId: null, damId: null, generation: 0 },
    { id: "d", sireId: null, damId: null, generation: 0 },
    { id: "x", sireId: "s", damId: "d", generation: 1 },
    { id: "y", sireId: "s", damId: "d", generation: 1 },
  ]);
  assert.equal(projectedOffspringF("x", "y", p), 0.25);
});
test("F: half-sib = 0.125", () => {
  const p = buildPedigree([
    { id: "s", sireId: null, damId: null, generation: 0 },
    { id: "m1", sireId: null, damId: null, generation: 0 },
    { id: "m2", sireId: null, damId: null, generation: 0 },
    { id: "x", sireId: "s", damId: "m1", generation: 1 },
    { id: "y", sireId: "s", damId: "m2", generation: 1 },
  ]);
  assert.equal(projectedOffspringF("x", "y", p), 0.125);
});
test("F: tidak sedarah = 0", () => {
  assert.equal(projectedOffspringF("s", "d", ped()), 0);
});
test("F: kawin induk-anak = 0.25", () => {
  const p = buildPedigree([
    { id: "s", sireId: null, damId: null, generation: 0 },
    { id: "d", sireId: null, damId: null, generation: 0 },
    { id: "c", sireId: "s", damId: "d", generation: 1 }, // anak
  ]);
  assert.equal(projectedOffspringF("s", "c", p), 0.25); // induk x anak
});
test("classify: ambang benar", () => {
  assert.equal(classifyInbreeding(0.03), "SAFE");
  assert.equal(classifyInbreeding(0.1), "MODERATE");
  assert.equal(classifyInbreeding(0.25), "HIGH");
});

// ---------------- order helpers ----------------
const P = (id, sup, price, min) => ({ id, supplierId: sup, name: id, pricePerUnit: price, minOrderQty: min });
test("cart: tolak di bawah minimum", () => {
  const v = validateCart([{ product: P("A", "s1", 6000, 50), quantity: 10 }]);
  assert.equal(v.ok, false);
});
test("cart: lolos & subtotal benar", () => {
  const lines = [
    { product: P("A", "s1", 6000, 10), quantity: 20 },
    { product: P("B", "s1", 3500, 10), quantity: 10 },
  ];
  assert.equal(validateCart(lines).ok, true);
  assert.equal(orderSubtotal(lines), 20 * 6000 + 10 * 3500);
});
test("cart: pisah per supplier", () => {
  const lines = [
    { product: P("A", "s1", 6000, 1), quantity: 5 },
    { product: P("B", "s2", 3500, 1), quantity: 5 },
    { product: P("C", "s1", 11000, 1), quantity: 5 },
  ];
  const batches = splitBySupplier(lines);
  assert.equal(batches.length, 2);
  assert.equal(batches.find((b) => b.supplierId === "s1").lines.length, 2);
});
