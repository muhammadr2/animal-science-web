-- supabase-payments.sql — kolom untuk integrasi Midtrans. Jalankan sekali.
alter table orders add column if not exists midtrans_order_id text;
alter table orders add column if not exists payment_status  text default 'UNPAID';
create index if not exists idx_orders_midtrans on orders(midtrans_order_id);

-- payment_status: UNPAID | PENDING | PAID | REVIEW | FAILED
-- status (sudah ada):  PENDING | CONFIRMED | CANCELLED
