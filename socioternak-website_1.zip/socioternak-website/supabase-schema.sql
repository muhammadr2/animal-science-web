-- ===========================================================================
-- SocioTernak — standalone site schema (paste into Supabase → SQL Editor → Run)
-- Snake_case tables that match index.html exactly. Run once.
-- ===========================================================================
create extension if not exists pgcrypto;   -- for gen_random_uuid()

-- ---------- tables ----------
create table if not exists sensors (
  id    uuid primary key default gen_random_uuid(),
  code  text unique not null,
  type  text not null,          -- TEMPERATURE | HUMIDITY | AMMONIA | WATER_FLOW | FEED_LEVEL
  unit  text not null,
  label text
);

create table if not exists sensor_logs (
  id          bigint generated always as identity primary key,
  sensor_id   uuid references sensors(id) on delete cascade,
  value       double precision not null,
  recorded_at timestamptz not null default now()
);
create index if not exists idx_sensor_logs on sensor_logs(sensor_id, recorded_at desc);

create table if not exists animals (
  id         uuid primary key default gen_random_uuid(),
  tag_id     text unique not null,
  sex        text,
  generation int default 0,
  sire_id    uuid references animals(id),
  dam_id     uuid references animals(id)
);

create table if not exists breeding_records (
  id           uuid primary key default gen_random_uuid(),
  sire_id      uuid references animals(id),
  dam_id       uuid references animals(id),
  mating_date  date default now(),
  inbreeding_f double precision,
  heritability double precision,
  notes        text,
  created_at   timestamptz default now()
);

create table if not exists products (
  id             uuid primary key default gen_random_uuid(),
  name           text unique not null,
  unit           text default 'kg',
  price_per_unit numeric not null,
  cp_percent     numeric,
  min_order_qty  numeric default 1
);

create table if not exists orders (
  id         uuid primary key default gen_random_uuid(),
  buyer_name text,
  subtotal   numeric not null,
  status     text default 'PENDING',
  created_at timestamptz default now()
);

create table if not exists order_items (
  id         uuid primary key default gen_random_uuid(),
  order_id   uuid references orders(id) on delete cascade,
  product_id uuid references products(id),
  quantity   numeric not null,
  unit_price numeric not null
);

-- ---------- Row-Level Security ----------
-- ⚠️ DEMO POLICIES: these grant the public anon key full access so the static
-- site works with no login. This is fine for a prototype but INSECURE for
-- production. Before going live with real farms, replace each policy with
-- auth-based rules (see supabase/policies.sql from the Next.js pillar files).
alter table sensors          enable row level security;
alter table sensor_logs      enable row level security;
alter table animals          enable row level security;
alter table breeding_records enable row level security;
alter table products         enable row level security;
alter table orders           enable row level security;
alter table order_items      enable row level security;

create policy demo_all on sensors          for all to anon using (true) with check (true);
create policy demo_all on sensor_logs      for all to anon using (true) with check (true);
create policy demo_all on animals          for all to anon using (true) with check (true);
create policy demo_all on breeding_records for all to anon using (true) with check (true);
create policy demo_all on products         for all to anon using (true) with check (true);
create policy demo_all on orders           for all to anon using (true) with check (true);
create policy demo_all on order_items      for all to anon using (true) with check (true);

-- ---------- Realtime (live sensor stream) ----------
alter publication supabase_realtime add table sensor_logs;

-- ---------- seed data ----------
insert into sensors (code,type,unit,label) values
  ('A01-TEMP','TEMPERATURE','°C','Suhu'),
  ('A01-HUM','HUMIDITY','%','Kelembapan'),
  ('A01-NH3','AMMONIA','ppm','Amonia'),
  ('A01-WATER','WATER_FLOW','L/min','Aliran air'),
  ('A01-FEED','FEED_LEVEL','%','Stok pakan')
on conflict (code) do nothing;

insert into products (name,unit,price_per_unit,cp_percent,min_order_qty) values
  ('Jagung','kg',6000,8.5,50),
  ('Dedak padi','kg',3500,12,50),
  ('Bungkil kedelai','kg',11000,44,25)
on conflict (name) do nothing;

-- founders + full-sib pair sharing both parents (offspring F should = 0.25)
insert into animals (tag_id,sex,generation) values
  ('GA-01','MALE',0),('GA-02','FEMALE',0)
on conflict (tag_id) do nothing;

insert into animals (tag_id,sex,generation,sire_id,dam_id)
  select 'PJ-114','MALE',2,(select id from animals where tag_id='GA-01'),(select id from animals where tag_id='GA-02')
on conflict (tag_id) do nothing;

insert into animals (tag_id,sex,generation,sire_id,dam_id)
  select 'BT-207','FEMALE',2,(select id from animals where tag_id='GA-01'),(select id from animals where tag_id='GA-02')
on conflict (tag_id) do nothing;
