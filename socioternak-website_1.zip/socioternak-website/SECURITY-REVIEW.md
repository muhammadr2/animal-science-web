# SocioTernak — Review Keamanan RLS

**Penting & jujur:** ini review yang saya (Claude) lakukan sendiri terhadap kode, **bukan
audit independen**. Sebelum menaruh data peternak sungguhan dalam skala besar — apalagi
uang — mintalah orang lain yang paham keamanan meninjau ulang. Anggap dokumen ini sebagai
titik awal, bukan sertifikasi.

## Ringkasan
Model dasar (RLS berbasis `auth.uid()` per pemilik) sudah benar dan mengisolasi data
antar-peternak, termasuk pada Realtime. Namun ada beberapa celah yang perlu ditutup;
semuanya diperbaiki oleh `supabase-hardening.sql`.

## Temuan

| # | Tingkat | Masalah | Perbaikan |
|---|---------|---------|-----------|
| H1 | **Tinggi** | Policy `p_self_upd` mengizinkan user meng-update baris profilnya sendiri termasuk kolom `role` → user bisa menaikkan dirinya jadi `ADMIN`. | `revoke update (role)` dari `authenticated`. Peran hanya diubah lewat SQL/service role. |
| H2 | Sedang | Tabel `products` hanya punya policy SELECT; tak ada aturan tulis (form admin tak berfungsi, atau bila dibiarkan bisa salah konfigurasi). | Policy tulis khusus `ADMIN`/`SUPPLIER`. |
| H4 | **Tinggi (untuk marketplace berbayar)** | `orders.subtotal`, `order_items.unit_price`, `quantity` dikirim dari klien → harga bisa dimanipulasi (mis. subtotal 0). | RPC `create_order` menghitung ulang harga dari tabel `products` di server. Wajib dipakai sebelum ada pembayaran. |
| H3 | Rendah | Tak ada batasan nilai; kuantitas/harga negatif bisa masuk. | CHECK constraint (`quantity>0`, `price>=0`, dll). |
| — | Info | Skema demo permisif (`supabase-schema.sql`) memberi anon akses penuh. | **Jangan** pernah jalankan file itu di project produksi. Pakai `-secure`. |
| — | Info | Anon key tampil di browser. | Ini normal & aman **selama RLS benar** — keamanan bukan dari menyembunyikan key. |
| — | Info | Signup anonim membuat baris starter tiap akun. | Aktifkan konfirmasi email + (opsional) CAPTCHA di Supabase untuk produksi agar tak dispam. |
| — | Info | Service role key di `iot-bridge`. | Hanya di server. Jangan pernah di `index.html`. Rotasi bila bocor. |

## Yang sudah benar
- Isolasi per pemilik di `farms/coops/sensors/sensor_logs/animals/breeding_records/orders/order_items`.
- Realtime hanya mengekspos `sensor_logs`, dan RLS tetap berlaku pada stream (peternak lain tak menerima data Anda).
- `tag_id` unik per pemilik, bukan global.
- Insert log via bridge memakai service role (server), bukan kredensial browser.

## Cara memakai `create_order` (setelah menjalankan hardening)
Ganti isi `createOrder()` di `index.html` (bagian LIVE) menjadi:
```js
const {data:oid,error}=await sb.rpc("create_order",{
  items: lines.map(l=>({product_id:l.p.id, quantity:l.q}))
});
if(error){toast("Gagal: "+error.message);return;}
toast("Pesanan tersimpan ✓ (harga dihitung server)"); cart={}; renderProducts();
```
Dengan ini subtotal tidak lagi dipercaya dari klien.

## Checklist sebelum go-live nyata (di luar kode)
- [ ] Aktifkan konfirmasi email di Supabase Auth.
- [ ] Aktifkan Point-in-Time Recovery / backup terjadwal (Supabase → Database → Backups).
- [ ] Pantau log & error (Supabase Logs, atau integrasi seperti Sentry).
- [ ] Batasi rate signup (CAPTCHA/hCaptcha di Auth).
- [ ] Review independen atas policy RLS ini oleh pihak lain.
- [ ] Jalankan `create_order` (H4) sebelum mengaktifkan pembayaran.
