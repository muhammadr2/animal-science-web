-- ===========================================================================
-- SocioTernak — SECURE multi-tenant schema (untuk pemakaian nyata / pilot)
-- Setiap peternak hanya bisa melihat & mengubah datanya sendiri (via RLS).
-- Jalankan di Supabase → SQL Editor. Butuh Auth (email/password) aktif.
--
-- ⚠️ Script ini MENGHAPUS tabel demo lama lalu membangun ulang versi aman.
--    Data demo sebelumnya akan hilang. Jalankan di project baru bila ragu.
-- ===========================================================================
drop table if exists order_items, orders, breeding_records, sensor_logs,
                     sensors, coops, farms, animals, products, profiles cascade;
drop function if exists public.handle_new_user cascade;

create extension if not exists pgcrypto;

-- ---------- tabel ----------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text, role text default 'FARMER', created_at timestamptz default now()
);
create table farms (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null, location text, created_at timestamptz default now()
);
create table coops (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references farms(id) on delete cascade,
  name text not null, type text default 'CLOSE_HOUSE', capacity int
);
create table sensors (
  id uuid primary key default gen_random_uuid(),
  coop_id uuid not null references coops(id) on delete cascade,
  code text unique not null, type text not null, unit text not null, label text
);
create table sensor_logs (
  id bigint generated always as identity primary key,
  sensor_id uuid not null references sensors(id) on delete cascade,
  value double precision not null, recorded_at timestamptz not null default now()
);
create index idx_sensor_logs on sensor_logs(sensor_id, recorded_at desc);
create table animals (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  tag_id text not null, sex text, generation int default 0,
  sire_id uuid references animals(id), dam_id uuid references animals(id),
  unique(owner_id, tag_id)
);
create table breeding_records (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  sire_id uuid references animals(id), dam_id uuid references animals(id),
  mating_date date default now(), inbreeding_f double precision,
  heritability double precision, notes text, created_at timestamptz default now()
);
create table products (           -- katalog bersama (dibaca semua user login)
  id uuid primary key default gen_random_uuid(),
  name text unique not null, unit text default 'kg',
  price_per_unit numeric not null, cp_percent numeric, min_order_qty numeric default 1
);
create table orders (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid not null references auth.users(id) on delete cascade,
  subtotal numeric not null, status text default 'PENDING', created_at timestamptz default now()
);
create table order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid references products(id), quantity numeric not null, unit_price numeric not null
);

-- ---------- privilege dasar (RLS yang membatasi, bukan privilege) ----------
grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant usage, select on all sequences in schema public to authenticated;
grant select on products to anon;

-- ---------- Row-Level Security ----------
alter table profiles enable row level security;
alter table farms enable row level security;
alter table coops enable row level security;
alter table sensors enable row level security;
alter table sensor_logs enable row level security;
alter table animals enable row level security;
alter table breeding_records enable row level security;
alter table products enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;

create policy p_self     on profiles for select using (id = auth.uid());
create policy p_self_upd on profiles for update using (id = auth.uid());

create policy f_owner on farms for all
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy c_owner on coops for all
  using (exists (select 1 from farms f where f.id = coops.farm_id and f.owner_id = auth.uid()))
  with check (exists (select 1 from farms f where f.id = coops.farm_id and f.owner_id = auth.uid()));

create policy s_owner on sensors for all
  using (exists (select 1 from coops c join farms f on f.id=c.farm_id
                 where c.id = sensors.coop_id and f.owner_id = auth.uid()))
  with check (exists (select 1 from coops c join farms f on f.id=c.farm_id
                 where c.id = sensors.coop_id and f.owner_id = auth.uid()));

create policy sl_read on sensor_logs for select
  using (exists (select 1 from sensors s join coops c on c.id=s.coop_id join farms f on f.id=c.farm_id
                 where s.id = sensor_logs.sensor_id and f.owner_id = auth.uid()));
create policy sl_insert on sensor_logs for insert
  with check (exists (select 1 from sensors s join coops c on c.id=s.coop_id join farms f on f.id=c.farm_id
                 where s.id = sensor_logs.sensor_id and f.owner_id = auth.uid()));

create policy a_owner  on animals for all
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy br_owner on breeding_records for all
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy pr_read on products for select to authenticated using (true);

create policy o_owner  on orders for all
  using (buyer_id = auth.uid()) with check (buyer_id = auth.uid());
create policy oi_owner on order_items for all
  using (exists (select 1 from orders o where o.id = order_items.order_id and o.buyer_id = auth.uid()))
  with check (exists (select 1 from orders o where o.id = order_items.order_id and o.buyer_id = auth.uid()));

-- ---------- Realtime ----------
alter publication supabase_realtime add table sensor_logs;

-- ---------- data awal otomatis per pengguna baru ----------
-- Saat seseorang mendaftar, buatkan profil + 1 peternakan + 1 kandang +
-- 5 sensor + silsilah awal (PJ-114 × BT-207 = full-sib, F keturunan 25%).
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare fid uuid; cid uuid; ga1 uuid; ga2 uuid;
begin
  insert into profiles(id, full_name)
    values (new.id, coalesce(new.raw_user_meta_data->>'full_name','Peternak'));
  insert into farms(owner_id, name) values (new.id, 'Peternakan Saya') returning id into fid;
  insert into coops(farm_id, name, type, capacity)
    values (fid, 'Close House A-01', 'CLOSE_HOUSE', 5000) returning id into cid;
  insert into sensors(coop_id, code, type, unit, label) values
    (cid, cid::text||'-TEMP','TEMPERATURE','°C','Suhu'),
    (cid, cid::text||'-HUM','HUMIDITY','%','Kelembapan'),
    (cid, cid::text||'-NH3','AMMONIA','ppm','Amonia'),
    (cid, cid::text||'-WATER','WATER_FLOW','L/min','Aliran air'),
    (cid, cid::text||'-FEED','FEED_LEVEL','%','Stok pakan');
  insert into animals(owner_id,tag_id,sex,generation) values (new.id,'GA-01','MALE',0)   returning id into ga1;
  insert into animals(owner_id,tag_id,sex,generation) values (new.id,'GA-02','FEMALE',0) returning id into ga2;
  insert into animals(owner_id,tag_id,sex,generation,sire_id,dam_id) values (new.id,'PJ-114','MALE',2,ga1,ga2);
  insert into animals(owner_id,tag_id,sex,generation,sire_id,dam_id) values (new.id,'BT-207','FEMALE',2,ga1,ga2);
  return new;
end; $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- katalog pakan (bersama)
insert into products(name,unit,price_per_unit,cp_percent,min_order_qty) values
  ('Jagung','kg',6000,8.5,50),('Dedak padi','kg',3500,12,50),('Bungkil kedelai','kg',11000,44,25)
on conflict (name) do nothing;
