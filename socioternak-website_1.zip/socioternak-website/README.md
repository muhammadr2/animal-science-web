# SocioTernak — platform (siap pilot)

Website satu file (`index.html`) + Supabase + jembatan IoT. Jalan DEMO tanpa setup,
atau LIVE dengan login nyata, isolasi data antar-peternak, sensor sungguhan, dan CRUD ternak.

## Isi folder
```
index.html                    seluruh website (DEMO / LIVE)
supabase-schema-secure.sql    skema aman + login + RLS per-pengguna   ← pakai ini
supabase-hardening.sql        penguatan keamanan (jalankan setelah -secure)
supabase-schema.sql           skema demo permisif (hanya coba cepat, JANGAN utk produksi)
SECURITY-REVIEW.md            review RLS + celah + perbaikan
iot-bridge/                   jembatan MQTT -> Supabase untuk sensor asli
  bridge.js  simulator.js  package.json  .env.example
README.md
```

## Aktifkan LIVE (aman)
1. Buat project di supabase.com.
2. Authentication → Providers → Email: aktifkan (matikan "Confirm email" utk uji cepat).
3. SQL Editor: jalankan `supabase-schema-secure.sql`, lalu `supabase-hardening.sql`.
4. Settings → API: salin Project URL + anon key.
5. Isi bagian KONFIGURASI di `index.html`, simpan, buka. Muncul login → Daftar
   (otomatis dibuatkan 1 peternakan, 1 kandang, 5 sensor, silsilah awal).

## Fitur
- **Beranda** — hero, kartu fitur, kalkulator ROI.
- **Dashboard IoT** — kartu status + grafik + toggle; Realtime dari `sensor_logs`.
- **Genetika** — F inbreeding (manual & dari database, koansestri rekursif).
- **Ternak** — CRUD ternak (tambah/ubah/hapus), langsung mengubah silsilah.
- **Pakan** — least-cost optimizer + marketplace (order tersimpan; form produk utk admin/supplier).
- **Auth** — login/daftar, keluar, **lupa password** (reset via email).

## Sensor asli (iot-bridge)
Perangkat publish MQTT → `bridge.js` menulis ke `sensor_logs` (service role) → dashboard
update via Realtime. Uji tanpa hardware: `npm install` lalu `npm run simulate` (butuh
broker MQTT + `.env`). Perangkat publish ke `socioternak/<coop_id>/<sensor_code>` payload
`{"value":31.4}`. Bridge dijalankan di server yang selalu hidup (Railway/Fly.io/VPS), bukan Vercel.

## Peran (admin/supplier)
`role` ada di tabel `profiles` (default FARMER). Set ke ADMIN/SUPPLIER lewat SQL untuk
memunculkan form "Tambah produk". Perubahan role dari browser diblokir (lihat SECURITY-REVIEW H1).

## Deploy
Seret folder ke app.netlify.com/drop, atau GitHub Pages / Vercel (static).
*(Langkah dashboard tiap platform bisa berubah — ikuti dokumentasi terbaru bila berbeda.)*

## Batas jujur — yang BELUM selesai (bukan "100% produksi")
- **Pembayaran nyata TIDAK diimplementasikan.** Menangkap pembayaran butuh secret key +
  webhook di server; **tidak bisa aman dari situs statis.** Status order hanya PENDING.
  Untuk produksi: pasang Midtrans/Stripe lewat Supabase Edge Function (server), lalu
  panggil dari sini. Saya sengaja tidak memalsukannya.
- **Audit keamanan independen** belum dilakukan — SECURITY-REVIEW.md adalah review saya sendiri.
- **Backup, monitoring, rate-limit** = pengaturan operasional (checklist di SECURITY-REVIEW.md),
  bukan kode.
- Kalibrasi ambang sensor, harga, dan angka ROI ke data Anda sebelum dipakai serius.

Ini cukup untuk **pilot terbatas dengan peternak nyata & sensor nyata**. Sisa di atas adalah
langkah menuju skala penuh.

---

## Tambahan: tes, pembayaran, pitch (paket akhir)

### Uji otomatis
`lib/agtech-core.mjs` + `tests/core.test.mjs`. Jalankan:
```bash
node --test
```
Menguji logika inti: F inbreeding (full-sib 0.25, half-sib 0.125, induk-anak 0.25),
optimizer pakan, alert engine sensor, validasi & split order. **14/14 lulus.**

### Pembayaran (Midtrans) — lihat PAYMENTS.md
- `supabase/functions/create-payment/` — buat transaksi Snap (server key aman di server).
- `supabase/functions/payment-webhook/` — verifikasi tanda tangan SHA-512, update status order.
- `supabase-payments.sql` — kolom pembayaran.
- Aktif bila `MIDTRANS_CLIENT_KEY` diisi di `index.html`; jika kosong, order tetap tersimpan tanpa bayar.
- **Belum diuji terhadap Midtrans** — wajib uji di sandbox (detail & peringatan di PAYMENTS.md).

### Pitch deck
`SocioTernak-Pitch.pptx` — 11 slide investor. Angka pasar & finansial sengaja berupa
placeholder `[isi ...]` agar Anda mengisinya dengan data tersitasi; tidak ada statistik yang dikarang.
