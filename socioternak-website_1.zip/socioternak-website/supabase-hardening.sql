-- ===========================================================================
-- SocioTernak — HARDENING (jalankan SETELAH supabase-schema-secure.sql)
-- Menutup celah yang ditemukan di SECURITY-REVIEW.md.
-- ===========================================================================

-- [H1] Cegah eskalasi hak: user TIDAK boleh mengubah kolom `role` miliknya
--      (policy update self sebelumnya mengizinkan ubah kolom apa pun).
--      Ubah peran hanya lewat SQL/service role.
revoke update (role) on profiles from authenticated;

-- [H2] Izin tulis katalog produk hanya untuk ADMIN / SUPPLIER.
--      (Sebelumnya products hanya punya policy SELECT → tidak ada yang bisa menulis
--       dari client. Ini mengaktifkan form "Tambah produk" untuk peran tsb.)
drop policy if exists pr_admin_write on products;
create policy pr_admin_write on products for all to authenticated
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.role in ('ADMIN','SUPPLIER')))
  with check (exists (select 1 from profiles p where p.id = auth.uid() and p.role in ('ADMIN','SUPPLIER')));

-- [H3] Batasan nilai (CHECK) agar data sampah/negatif ditolak di level DB.
do $$
begin
  begin alter table order_items add constraint chk_qty_pos     check (quantity > 0);       exception when duplicate_object then null; end;
  begin alter table order_items add constraint chk_price_nonneg check (unit_price >= 0);    exception when duplicate_object then null; end;
  begin alter table orders      add constraint chk_subtotal_nn  check (subtotal >= 0);      exception when duplicate_object then null; end;
  begin alter table animals     add constraint chk_gen_nonneg   check (generation >= 0);    exception when duplicate_object then null; end;
  begin alter table products    add constraint chk_price_pos    check (price_per_unit >= 0);exception when duplicate_object then null; end;
end $$;

-- [H4] Order aman: hitung subtotal & harga di SERVER, bukan dari klien.
--      Mencegah manipulasi harga (klien mengirim subtotal=0, dll).
--      Setelah menjalankan ini, ganti createOrder() di index.html agar memakai RPC
--      (lihat SECURITY-REVIEW.md bagian "Cara memakai create_order").
create or replace function public.create_order(items jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare oid uuid; sub numeric := 0; it jsonb; pid uuid; qty numeric; pr numeric;
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;

  for it in select * from jsonb_array_elements(items) loop
    pid := (it->>'product_id')::uuid;
    qty := (it->>'quantity')::numeric;
    if qty is null or qty <= 0 then raise exception 'quantity tidak valid'; end if;
    select price_per_unit into pr from products where id = pid;
    if pr is null then raise exception 'produk tidak ditemukan'; end if;
    sub := sub + pr * qty;
  end loop;

  insert into orders(buyer_id, subtotal, status) values (auth.uid(), sub, 'PENDING') returning id into oid;

  for it in select * from jsonb_array_elements(items) loop
    pid := (it->>'product_id')::uuid;
    qty := (it->>'quantity')::numeric;
    select price_per_unit into pr from products where id = pid;
    insert into order_items(order_id, product_id, quantity, unit_price) values (oid, pid, qty, pr);
  end loop;

  return oid;
end $$;
grant execute on function public.create_order(jsonb) to authenticated;
